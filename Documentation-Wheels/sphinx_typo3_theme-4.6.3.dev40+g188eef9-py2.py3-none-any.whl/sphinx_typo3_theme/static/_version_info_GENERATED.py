version_info = (
{
  "build_mtime": "1635442341",
  "module_name": "sphinx_typo3_theme",
  "version_scm": "4.6.3.dev40+g188eef9",
  "version_scm_build": "g188eef9",
  "version_scm_core": "4.6.3",
  "version_scm_pre_release": "dev40"
}
)
